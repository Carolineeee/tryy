// #1
let year = 2021;
console.log(year);

// #2
console.log(year + " hello");

// #3
let z
console.log(z);

// #4
const assignment = "assignment2";
console.log(assignment);
//const assignment = 20;
//console.log(assignment);

// #5
const empty = "";

// #6
if (empty == "" || empty === true){
    console.log("An empty string equals true")
}
else {
    console.log("An empty string equals false");
}

// #7
let a = 5;
let b = 3;
console.log(a+b);

// #8 idk ask!
console.log(a -= b);
//console.log(a -= b, a);

// #9
let id = "A00979543";
let myName =  " Diana Collado";

// #10
console.log(id + myName);